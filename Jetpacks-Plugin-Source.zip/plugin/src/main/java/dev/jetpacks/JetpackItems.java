package dev.jetpacks;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public final class JetpackItems {
    public static final NamespacedKey TYPE_KEY = NamespacedKey.fromString("jetpacks:type");

    private JetpackItems() {}

    public static ItemStack create(JetpackType type) {
        ItemStack item = new ItemStack(type.base);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text(type.displayName, type.color).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Двічі натисни Пробіл у повітрі, щоб летіти", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Паливо: ", NamedTextColor.DARK_GRAY)
                        .append(Component.translatable(type.fuel.translationKey(), NamedTextColor.GOLD))
                        .append(Component.text(" (" + type.secondsPerFuel + " с / шт.)", NamedTextColor.DARK_GRAY))
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Можна прикрашати орнаментами (armor trim)", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        // Іконка + вигляд на персонажі (з ресурспаку)
        NamespacedKey model = NamespacedKey.fromString("jetpacks:" + type.id);
        meta.setItemModel(model);
        EquippableComponent eq = meta.getEquippable();
        eq.setSlot(EquipmentSlot.CHEST);
        eq.setModel(model);
        meta.setEquippable(eq);

        meta.getPersistentDataContainer().set(TYPE_KEY, PersistentDataType.STRING, type.id);
        item.setItemMeta(meta);
        return item;
    }

    public static JetpackType typeOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer().get(TYPE_KEY, PersistentDataType.STRING);
        return id == null ? null : JetpackType.byId(id);
    }
}
