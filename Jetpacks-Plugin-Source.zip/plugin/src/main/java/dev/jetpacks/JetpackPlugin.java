package dev.jetpacks;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.recipe.CraftingBookCategory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class JetpackPlugin extends JavaPlugin implements Listener {

    private static final int PERIOD = 2; // тіків між перевірками

    private final List<NamespacedKey> recipeKeys = new ArrayList<>();
    private final Map<UUID, Integer> fuelTicks = new HashMap<>();
    private final Map<UUID, Long> lastFlight = new HashMap<>();
    private final Set<UUID> granted = new HashSet<>();
    private int soundCounter = 0;

    @Override
    public void onEnable() {
        registerRecipes();
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, PERIOD);
        getLogger().info("Jetpacks увімкнено.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) release(p);
        for (NamespacedKey k : recipeKeys) Bukkit.removeRecipe(k);
    }

    // ---------------------------------------------------------------- рецепти

    private void registerRecipes() {
        add(JetpackType.IRON, new String[]{"ICI", "IHI", "RFR"},
                Map.of('I', Material.IRON_INGOT, 'C', Material.IRON_CHESTPLATE, 'H', Material.HOPPER,
                        'R', Material.REDSTONE, 'F', Material.FURNACE));
        add(JetpackType.DIAMOND, new String[]{"DCD", "DHD", "BFB"},
                Map.of('D', Material.DIAMOND, 'C', Material.DIAMOND_CHESTPLATE, 'H', Material.HOPPER,
                        'B', Material.BLAZE_ROD, 'F', Material.BLAST_FURNACE));
        add(JetpackType.NETHERITE, new String[]{"NCN", "NHN", "PEP"},
                Map.of('N', Material.NETHERITE_INGOT, 'C', Material.NETHERITE_CHESTPLATE, 'H', Material.HOPPER,
                        'P', Material.PHANTOM_MEMBRANE, 'E', Material.END_CRYSTAL));
    }

    private void add(JetpackType type, String[] shape, Map<Character, Material> ingredients) {
        NamespacedKey key = new NamespacedKey(this, type.id);
        ShapedRecipe recipe = new ShapedRecipe(key, JetpackItems.create(type));
        recipe.shape(shape);
        ingredients.forEach(recipe::setIngredient);
        recipe.setCategory(CraftingBookCategory.EQUIPMENT);
        Bukkit.removeRecipe(key);
        Bukkit.addRecipe(recipe);
        recipeKeys.add(key);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        e.getPlayer().discoverRecipes(recipeKeys);
    }

    /** Не дозволяємо витратити готовий джетпак як «нагрудник» у рецепті. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        if (!(e.getRecipe() instanceof Keyed keyed) || !recipeKeys.contains(keyed.getKey())) return;
        CraftingInventory inv = e.getInventory();
        for (ItemStack s : inv.getMatrix()) {
            if (JetpackItems.typeOf(s) != null) {
                inv.setResult(null);
                return;
            }
        }
    }

    // ---------------------------------------------------------------- політ

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            GameMode gm = p.getGameMode();
            UUID id = p.getUniqueId();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) {
                granted.remove(id);
                continue;
            }

            JetpackType type = JetpackItems.typeOf(p.getInventory().getChestplate());
            if (type == null) {
                release(p);
                continue;
            }

            boolean hasFuel = fuelTicks.getOrDefault(id, 0) > 0 || p.getInventory().contains(type.fuel);
            if (!hasFuel) {
                if (p.isFlying()) p.sendActionBar(Component.text("Паливо закінчилось!", NamedTextColor.RED));
                release(p);
                continue;
            }

            if (granted.add(id) || !p.getAllowFlight()) p.setAllowFlight(true);
            p.setFlySpeed(type.flySpeed);

            if (!p.isFlying()) continue;

            // витрата палива
            int rem = fuelTicks.getOrDefault(id, 0) - PERIOD;
            if (rem <= 0) {
                boolean took = !p.getInventory().removeItem(new ItemStack(type.fuel, 1)).values().iterator().hasNext();
                rem = took ? type.secondsPerFuel * 20 : 0;
            }
            fuelTicks.put(id, rem);
            lastFlight.put(id, p.getWorld().getGameTime());

            effects(p);

            int total = rem / 20 + countItems(p, type.fuel) * type.secondsPerFuel;
            p.sendActionBar(Component.text("Паливо: ", NamedTextColor.GRAY)
                    .append(Component.text(total + " с", type.color)));
        }
    }

    private void effects(Player p) {
        double yaw = Math.toRadians(p.getLocation().getYaw());
        double bx = Math.sin(yaw) * 0.35;   // позаду гравця
        double bz = -Math.cos(yaw) * 0.35;
        double sx = -Math.cos(yaw) * 0.2;   // вбік до сопел
        double sz = -Math.sin(yaw) * 0.2;
        var base = p.getLocation().add(bx, 0.55, bz);
        for (int side = -1; side <= 1; side += 2) {
            var loc = base.clone().add(sx * side, 0, sz * side);
            p.getWorld().spawnParticle(Particle.FLAME, loc, 2, 0.03, 0.05, 0.03, 0.01);
            p.getWorld().spawnParticle(Particle.SMOKE, loc, 1, 0.03, 0.05, 0.03, 0.01);
        }
        if (++soundCounter % 5 == 0) {
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.25f, 1.6f);
        }
    }

    private int countItems(Player p, Material m) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && s.getType() == m) n += s.getAmount();
        }
        return n;
    }

    private void release(Player p) {
        UUID id = p.getUniqueId();
        if (granted.remove(id)) {
            p.setFlying(false);
            p.setAllowFlight(false);
            p.setFlySpeed(0.1f);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        release(e.getPlayer());
        fuelTicks.remove(e.getPlayer().getUniqueId());
        lastFlight.remove(e.getPlayer().getUniqueId());
    }

    /** Невеликий «грейс» без урону від падіння одразу після польоту. */
    @EventHandler
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        Long last = lastFlight.get(p.getUniqueId());
        if (p.isFlying() || (last != null && p.getWorld().getGameTime() - last <= 40)) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- команда

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length >= 2 && args[0].equalsIgnoreCase("give")) {
            JetpackType type = JetpackType.byShortName(args[1]);
            if (type == null) {
                sender.sendMessage(Component.text("Невідомий тип. Доступні: iron, diamond, netherite", NamedTextColor.RED));
                return true;
            }
            Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2])
                    : (sender instanceof Player pl ? pl : null);
            if (target == null) {
                sender.sendMessage(Component.text("Гравця не знайдено.", NamedTextColor.RED));
                return true;
            }
            target.getInventory().addItem(JetpackItems.create(type))
                    .values().forEach(it -> target.getWorld().dropItemNaturally(target.getLocation(), it));
            sender.sendMessage(Component.text("Видано: " + type.displayName + " → " + target.getName(), NamedTextColor.GREEN));
            return true;
        }
        sender.sendMessage(Component.text("/jetpack give <iron|diamond|netherite> [гравець]", NamedTextColor.YELLOW));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) return List.of("give");
        if (args.length == 2) return List.of("iron", "diamond", "netherite");
        return null; // імена гравців
    }
}
