package dev.jetpacks;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Material;

public enum JetpackType {
    //        id                 назва                  колір                  база (захист)                 паливо                 сек/1 шт  швидкість
    IRON     ("iron_jetpack",     "Залізний джетпак",     NamedTextColor.GRAY,        Material.IRON_CHESTPLATE,      Material.COAL,         30, 0.05f),
    DIAMOND  ("diamond_jetpack",  "Алмазний джетпак",     NamedTextColor.AQUA,        Material.DIAMOND_CHESTPLATE,   Material.BLAZE_POWDER, 45, 0.075f),
    NETHERITE("netherite_jetpack","Незеритовий джетпак",  NamedTextColor.DARK_PURPLE, Material.NETHERITE_CHESTPLATE, Material.BLAZE_ROD,    90, 0.11f);

    public final String id;
    public final String displayName;
    public final TextColor color;
    public final Material base;
    public final Material fuel;
    public final int secondsPerFuel;
    public final float flySpeed;

    JetpackType(String id, String displayName, TextColor color, Material base, Material fuel, int secondsPerFuel, float flySpeed) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.base = base;
        this.fuel = fuel;
        this.secondsPerFuel = secondsPerFuel;
        this.flySpeed = flySpeed;
    }

    public static JetpackType byId(String id) {
        for (JetpackType t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public static JetpackType byShortName(String s) {
        for (JetpackType t : values()) if (t.name().equalsIgnoreCase(s)) return t;
        return null;
    }
}
