# Jetpacks (Purpur / Paper 26.x)

## Збірка плагіна
Потрібен JDK 25 і Gradle:  `cd plugin && gradle build`  → `plugin/build/libs/Jetpacks-1.0.0.jar` у `plugins/`.

## Ресурспак
`Jetpacks-ResourcePack.zip` — або в `server.properties` (resource-pack=URL, resource-pack-sha1=..., require-resource-pack=true),
або кладеш у свій пак-менеджер. Без паку предмети виглядатимуть як звичайні нагрудники.
Якщо клієнт скаржиться на формат паку — змін `min_format`/`max_format` у pack.mcmeta під свою версію.

## Крафт (ряд зверху вниз)
Залізний:      I C I / I H I / R F R   (I=залізо, C=залізний нагрудник, H=лійка, R=редстоун, F=піч)
Алмазний:      D C D / D H D / B F B   (D=алмаз, C=алмазний нагрудник, H=лійка, B=blaze rod, F=доменна піч)
Незеритовий:   N C N / N H N / P E P   (N=незерит, C=незер. нагрудник, H=лійка, P=phantom membrane, E=end crystal)

## Політ
Одягнути джетпак → двічі Пробіл у повітрі. Паливо береться з інвентаря:
залізний — вугілля (30 с), алмазний — blaze powder (45 с), незеритовий — blaze rod (90 с).
Команда: /jetpack give <iron|diamond|netherite> [гравець]  (право jetpacks.give)

## Орнаменти
Це справжній нагрудник (база = залізний/алмазний/незеритовий), тому armor trim
через стіл ковалів (шаблон + матеріал) працює, захист і міцність — ванільні.
